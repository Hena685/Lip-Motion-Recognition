# Placeholder for preprocessing utilities
class GridDataset:
    def __init__(self, path):
        pass
    def __getitem__(self, idx):
        pass
    def __len__(self):
        return 0

def collate_fn(batch):
    return [], [], [], []