# Non-Auditory Speech Recognition via Lip Motion Analysis

This project implements a hybrid deep learning model for lipreading using the GRID corpus.

## Components
- Spatiotemporal CNN (STCNN)
- Bi-GRU
- CTC Loss

## Usage
Download GRID Corpus from https://spandh.dcs.shef.ac.uk/gridcorpus/

```bash
pip install -r requirements.txt
python train.py
```

## Authors
Hena Basheer, Keshav Sairam, Monika Agarwal, Aparajita Sinha