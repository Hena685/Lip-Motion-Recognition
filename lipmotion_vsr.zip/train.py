from models.stcnn_bigru import STCNN_BiGRU
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import torch.optim as optim
from utils.preprocessing import GridDataset, collate_fn
from torch.nn.functional import ctc_loss

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = STCNN_BiGRU().to(device)
optimizer = optim.Adam(model.parameters(), lr=1e-4)

train_loader = DataLoader(GridDataset("data/train"), batch_size=4, collate_fn=collate_fn)

for epoch in range(20):
    model.train()
    for inputs, targets, input_lengths, target_lengths in train_loader:
        inputs = inputs.to(device)
        targets = targets.to(device)
        outputs = model(inputs)
        outputs = outputs.log_softmax(2).transpose(0, 1)

        loss = ctc_loss(outputs, targets, input_lengths, target_lengths)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(f"Epoch {epoch + 1}, Loss: {loss.item():.4f}")