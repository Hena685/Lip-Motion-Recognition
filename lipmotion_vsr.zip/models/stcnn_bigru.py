import torch
import torch.nn as nn

class STCNN_BiGRU(nn.Module):
    def __init__(self, input_dim=64, hidden_dim=256, num_classes=28):
        super(STCNN_BiGRU, self).__init__()
        self.conv3d = nn.Sequential(
            nn.Conv3d(1, 32, kernel_size=(3,5,5), stride=1, padding=(1,2,2)),
            nn.ReLU(),
            nn.MaxPool3d((1,2,2)),
            nn.Conv3d(32, 64, kernel_size=(3,5,5), stride=1, padding=(1,2,2)),
            nn.ReLU(),
            nn.MaxPool3d((1,2,2)),
        )
        self.gru = nn.GRU(input_dim, hidden_dim, bidirectional=True, batch_first=True)
        self.fc = nn.Linear(hidden_dim * 2, num_classes)

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.conv3d(x)
        b, c, t, h, w = x.size()
        x = x.view(b, t, -1)
        x, _ = self.gru(x)
        x = self.fc(x)
        return x